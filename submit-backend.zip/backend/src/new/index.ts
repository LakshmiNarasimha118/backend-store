import express from 'express'
const app: express.Application = express()

app.use(express.json())

const port: string = "0.0.0.0:3000"

app.listen(3000, function () {
    console.log(`app starting on: ${port}`)
})