import express, { Request, Response } from 'express'
import user from './handlers/user'
import order from './handlers/order'
import product from './handlers/product'
import dashboard from './handlers/dashboard'

const app: express.Application = express()
const address: string = "0.0.0.0:3000"

app.use(express.json())

app.get('/', function (req: Request, res: Response) {
    res.send('store frontend')
})

user(app);

order(app);

product(app);

dashboard(app);

app.listen(3000, function () {
    console.log(`app starting on: ${address}`)
})

export default app;
