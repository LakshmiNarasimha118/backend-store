import jwt from 'jsonwebtoken'
import express from 'express'

export interface RequestCustom extends express.Request
{
    decodeJwt: {user:{id: string, username: string}}
}

const verifyToken = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    try{    // error handling try function
        const customReq = req as RequestCustom
        const authorization = customReq.headers.authorization;
        const token = authorization?.split(' ')[1] || ''
        const decodeJwt = jwt.verify(token, process.env.TOKEN_SECRET!)
        customReq.decodeJwt = decodeJwt as {user:{id: string, username: string}}
        next()
    }
    catch(err){ //error handling catch function if any error occur it will catch the error and show that error
        res.status(401).json('Invalid Token')   //ststus 401 is unauthorised error
        return
    }
    
}

export default verifyToken