import express, { Request, Response } from 'express'
import { User, UserStore } from '../models/user'
import jwt from 'jsonwebtoken'
import verifyToken, {RequestCustom} from '../middleware/auth'

const store = new UserStore()

const create =createFunc;

async function createFunc (_req: Request, res: Response) { //creating async function
    try {   // error handling try function
        const user: User = {
            username: _req.body.username,
            firstname: _req.body.firstname,
            lastname: _req.body.lastname,
            password: _req.body.password
        }

        const newUser = await store.create(user)    // await function which helps us to complete the function then only go to another function

        var token = jwt.sign({user: newUser}, process.env.TOKEN_SECRET!)

        res.json({'token': token})
    } catch(err) {      //error handling catch function if any error occur it will catch the error and show that error
        res.status(400) //status 400 is refered as bad request
        res.json(err)
    }
}

  
const show = async (req: Request, res: Response) => {   //creating async function
    try {   // error handling try function
    const customReq = req as RequestCustom
    const user = await store.show(req.params.id)    // await function which helps us to complete the function then only go to another function
    res.json(user)
} catch(err) {  //error handling catch function if any error occur it will catch the error and show that error
    res.status(400) //status 400 is refered as bad request
    res.json(err)
}
  }


const userRoutes = (app:express.Application) => {
    app.post('/users', create)
    app.get('/users', verifyToken, async (_req: Request, res: Response) => {    //creating async function
        try {   // error handling try function
        const users = await store.index()       // await function which helps us to complete the function then only go to another function
        res.json(users)
    } catch(err) {  //error handling catch function if any error occur it will catch the error and show that error
        res.status(400) //status 400 is refered as bad request
        res.json(err)
    }
      } 
    )
    app.get('/users/:id', verifyToken, show )
    app.post('/authenticate', async (_req: Request, res: Response) => { //creating async function
        try {   // error handling try function
            const user: User = {
                username: _req.body.username,
                password: _req.body.password
            }
    
            const authUser = await store.authenticate(user.username, user.password) // await function which helps us to complete the function then only go to another function
            var token = jwt.sign({user: authUser}, process.env.TOKEN_SECRET!)
            res.json({'token': token})
        } catch(err) {  //error handling catch function if any error occur it will catch the error and show that error
            res.status(400) //status 400 is refered as bad request
            res.json(err)
        }
    }
    )
}

export default userRoutes