import express, { Request, Response } from 'express' //importing request and response from express 
import { Order, OrderStore } from '../models/order'
import verifyToken from '../middleware/auth'

const store = new OrderStore();

const create = async (_req: Request, res: Response) => {  //creating async function
    try {                                                // error handling try function
        const order: Order = {
            status: _req.body.status,
            user_id: _req.body.user_id
        }
        const newOrder = await store.create(order)        // await function which helps us to complete the function then only go to another function

        res.json(newOrder)
    } catch(err) {             //error handling catch function if any error occur it will catch the error and show that error 
        res.status(400)     //status 400 is refered as bad request
        res.json(err)
    }
}

const index = async (_req: Request, res: Response) => {     ////creating async function
  try {                                              // error handling try function
    const orders = await store.index()          // await function which helps us to complete the function then only go to another function
    res.json(orders)
  } catch(err) {      //error handling catch function if any error occur it will catch the error and show that error
    res.status(400)   //ststus 400 is refered as bad request
    res.json(err)
}
  }
  
  
  const show = async (req: Request, res: Response) => {  //creating async function
    try {       // error handling try function
     const order = await store.show(req.params.id)       // await function which helps us to complete the function then only go to another function
     res.json(order)
    } catch(err) {        //error handling catch function if any error occur it will catch the error and show that error 
      res.status(400)     //ststus 400 is refered as bad request
      res.json(err)
  }
  }

const OrderRoutes = (app: express.Application) => {
    app.post('/orders',verifyToken, create)    //posting the data to server '/orders'
    app.get('/orders', index)       //geting the data to server '/orders'
    app.get('/orders/:id',verifyToken, show)    //getting the data to server '/orders/;id'
    app.post('/orders/:id/products',verifyToken, async (_req: Request, res: Response) => {  //creating async function
      const order_id: string = _req.params.id
      const product_id: string = _req.body.product_id
      const quantity: number = parseInt(_req.body.quantity)
    
      try {           // error handling try function                                            
        const addedProduct = await store.addProduct(quantity, order_id, product_id)   // await function which helps us to complete the function then only go to another function
        res.json(addedProduct)
      } catch(err) {                //error handling catch function if any error occur it will catch the error and show that error 
        res.status(400)     //ststus 400 is refered as bad request
        res.json(err)
      }
  }
    )  
  }


export default OrderRoutes