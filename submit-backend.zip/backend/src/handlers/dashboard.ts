import express, { Request, Response } from 'express'            //importing request and response from express
import { DashboardQueries } from '../services/dashboard'
import verifyToken from '../middleware/auth'


const DashboardRoutes = (app: express.Application) => {
    app.get('/products-by-category', productByCategory)   //for getting the '/products-by-category'
    app.get('/order-by-userid',verifyToken, orderByUserId)      //for getting the '/order-by-userid'
    app.get('/complete-order-by-userid', verifyToken, completedOrderByUserId)   //for getting the '/complete-order-by-userid'
    app.get('/five-most-popular-product', async (_req:Request, res: Response) => {      //creating async function
        try{                                                                      // error handling try function
        const products = await dashboard.fiveMostPopularProduct();                  // await function which helps us to complete the function then only go to another function
        res.json(products);
        }
        catch(err){             //error handling catch function if any error occur it will catch the error and show that error 
            res.status(400) //ststus 400 is refered as bad request
            res.json(err)
        }
    }
    )       //for getting the '/five-most-popular-product'
  }

const dashboard = new DashboardQueries();

const productByCategory = async (_req:Request, res: Response) => {    //creating async function
    try{                                                                             // error handling try function
        const products = await dashboard.productByCategory(_req.body.category);   // await function which helps us to complete the function then only go to another function
    res.json(products);
    }
    catch(err){            //error handling catch function if any error occur it will catch the error and show that error 
        res.status(400)   //ststus 400 is refered as bad request
        res.json(err)
    }
}


const completedOrderByUserId = async (_req:Request, res: Response) => {     //creating async function
    try{                                                                        // error handling try function
    const orders = await dashboard.completedOrderByUserId(_req.body.user_id);      // await function which helps us to complete the function then only go to another function
    res.json(orders);
    }
    catch(err){         //error handling catch function if any error occur it will catch the error and show that error 
        res.status(400)  //ststus 400 is refered as bad request
        res.json(err)
    }
}

const orderByUserId = async (_req:Request, res: Response) => {    //creating async function
    try{                                                                 // error handling try function
    const orders = await dashboard.orderByUserId(_req.body.user_id);    // await function which helps us to complete the function then only go to another function
    res.json(orders);
    }
    catch(err){             //error handling catch function if any error occur it will catch the error and show that error 
        res.status(400)     //ststus 400 is refered as bad request
        res.json(err)
    }
}


export default DashboardRoutes