import express, { Request, Response } from 'express'//importing express
import { Product, ProductStore } from '../models/product'
import verifyToken, {RequestCustom} from '../middleware/auth'
import jwt from 'jsonwebtoken'

const store = new ProductStore();


const create = async (_req: Request, res: Response) => { //creating async function
    try {       // error handling try function
        const product: Product = {
            name: _req.body.name,
            price: _req.body.price,
            category: _req.body.category ?? null
        }
        const newOrder = await store.create(product)        // await function which helps us to complete the function then only go to another function

        res.json(newOrder)
    } catch(err) {      //error handling catch function if any error occur it will catch the error and show that error
        console.log(err)
        res.status(400)
        res.json(err)
    }
}

const index = async (_req: Request, res: Response) => {     //creating async function
    try {       // error handling try function
    const products = await store.index()        // await function which helps us to complete the function then only go to another function
    res.json(products)
    } catch(err) {      //error handling catch function if any error occur it will catch the error and show that error
        console.log(err)
        res.status(400)
        res.json(err)
    }
  }

const ProductRoutes = (app: express.Application) => {
    app.post('/products',verifyToken, create)
    app.get('/products', index)
    app.get('/products/:id',verifyToken, async (req: Request, res: Response) => {       //creating async function
        const customReq = req as RequestCustom
        const product = await store.show(req.params.id)     // await function which helps us to complete the function then only go to another function
        res.json(product)
  }
    )
}


export default ProductRoutes